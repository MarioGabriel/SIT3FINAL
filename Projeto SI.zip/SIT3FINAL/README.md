# SIT3
Project statement:
O projeto proposto na disciplina PMR3304 – Sistemas de Informação é uma plataforma para informar as melhores opções de hospitais e prontos socorros de acordo com proximidade, plano de saúde do usuário e tempo médio de atendimento. Após escolher sua opção, o usuário receberá o trajeto para chegar até o hospital e ainda poderá deixar pré-agendada sua consulta, reduzindo ainda mais o tempo de atendimento.
